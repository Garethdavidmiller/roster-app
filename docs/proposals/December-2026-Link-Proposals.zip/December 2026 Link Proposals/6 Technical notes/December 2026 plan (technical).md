# LINKS_DEC2026_PLAN.md — the Links workspace and the December 2026 timetable change

*Not version-stamped; not a runtime asset. Companion to `.claude/rules/links-design.md`, which stays
authoritative for how the workspace is built.*

> **"Dec 26" means the DECEMBER 2026 TIMETABLE CHANGE.** It is industry shorthand for a timetable
> change date, not for 26 December. This matters in this repo specifically: `roster-data.js` and
> `OTHER_DAYS.md` carry a separate rule about **Boxing Day (26 Dec)** never being a training day, and
> `isChristmasRD()` forces 25/26 December to rest days. The two are unrelated. Anywhere this document
> says Dec 2026 it means the timetable change; anywhere the code says 26 Dec it means Boxing Day.

---

# 🗓 DECEMBER 2026 READINESS — read this first

*Added v19.97 (external review). Everything below this dashboard is the research and the
implementation record, and it is worth reading — but December 2026 is now a real approaching event,
and this document had no view that answered "are we ready, and what is stopping us?"*

**The tool is essentially built. What remains is decisions and a meeting.** Every outstanding row
below is owned by somebody other than the developer.

> ## ⚠️ THE LINK IS 24 LINES, AND EXCLUDES THE BILINGUAL ROSTER (owner, Aug 2026)
>
> The plan changed after most of this document was written. The new link **does not include the
> bilingual roster at all** — not its lines, not its shift times, not its work. It is the CEA/main
> roster **widened from 20** to increase staffing, and it carries the **same four spare weeks** the
> roster has today. (A fifth was added at v20.01 and reverted at v20.02 — the FF11 finding that
> motivated it turned out to be the line-order optimiser clustering the cover weeks, not the spare
> count. See the generator section below.)
>
> **The LENGTH has moved twice: 22 at v19.98, corrected to 24 at v20.01** (owner — the earlier figure
> was misremembered). Evidence class **C** for both: no document behind either.
>
> **Read every 28- and 22-line figure below, and every 5-spare-week figure, as history.** The
> `Baseline` and `What the generator produces` sections are re-measured at **24 lines / 4 spare**
> (v20.02); anything else quoting an older length or spare count describes a
> superseded design and is left as the record of how the tool was built. `ROTATING_LINES` is 24 and
> every literal derives from it — the 22 → 24 move was one constant, four static fallbacks the parity
> test named, and a re-measure, against ~15 literals across five files for 28 → 22.
>
> Three things the change does NOT undo, which is most of the value in this document: the ORR factor
> work, the operating-window and demand features, and the finding that a service increase cannot be
> absorbed by making existing lines denser. That last one is now the *argument that was won* — 22
> widening to 24 is exactly the "the link has to get bigger" conclusion, arriving from the business
> rather than from this tool.

| Item | Status | Needed by | Blocker / owner |
|---|---|---|---|
| **Rotation length** | ✅ **24, main-only** (owner, Aug 2026) — 22 at v19.98, corrected v20.01. Evidence class C | — | — |
| **Spare weeks** | ✅ **4** — the same as the roster today. A fifth was added v20.01 and reverted v20.02 once its motivating FF11 finding proved to be an optimiser bug (owner) | — | — |
| **Existing 28-line designs** | ✅ **DECIDED (owner, 30 Aug 2026): BIN THEM.** Not kept as a record — the 28-line link is described in this document and in the module comments, which is where a record belongs; a stale design in the picker is a thing somebody opens and edits by mistake. **Execution is a click in the app and is not done yet** (soft delete ✕ → they sit in 🗑 Recently deleted until removed for good). **Generate the new 24-line design FIRST** — `canSoftDelete` refuses the last LIVE design, so binning them all requires one to exist, and that is the order the work wants anyway | Before a proposal is frozen | **Gareth** — the clicks |
| Timetable data (all three simplifiers) | ✅ Final — confirmed not provisional (owner, Aug 2026) | — | — |
| Existing roster baseline | ✅ Measured (corrected v19.79 — 9 / 8 consecutive days, not 15 / 14) | — | — |
| Operating-window setting | ✅ Shipped v19.54 | — | — |
| ORR fatigue factors (25 rows) | ✅ Shipped v19.46 (+ v19.48 / v19.69 / v21.97 corrections — the last read the ORR sheet at source and added the two rows nobody had implemented) | — | — |
| Demand overlay | ✅ Shipped v19.56 | — | — |
| Line-order objectives | ✅ Shipped v19.58–v19.60 | — | — |
| **Hard company limits — a controlled source** | ⚠️ **Cited to the policy, but the policy is not identified** | **Before management review** | **Gareth** — get the title, clause, staff group and effective date. Evidence class B required (ROADMAP.md → Evidence class) |
| **Sunday operating window** | ✅ **Settled (owner, 28 Sep 2026): no duty runs past 23:25 on a Sunday** — agreed practice, and it will remain so. The five later movements are outside the staffed window on every design, and the heat map keeps showing them as a neutral fact | — | — |
| **Contracted hours — today's duties cannot fill a 24-line link** | ✅ **Answered (owner, 29 Sep 2026)**: the December 2026 staffing levels and a 24-person link are both confirmed verbally, so the December staffing supplies the extra duty. Every sheet but one pays the 35h week exactly — 42,000 minutes Monday to Saturday — carrying **94–98 timed duties a week against today's 76**; Fifteen Turns is 60 minutes a week over. Background (v20.04; generator gated v20.98/v20.99): seeded from today's duties, 24 lines averages **29h 53m** a week against 35h, and the generator refuses a table that misses the contract in either direction | — | — |
| **Business staffing requirement** | ✅ **Confirmed verbally (owner, 29 Sep 2026)**, with the 24-person link and the Sunday cover (10 on a Sunday, worked as overtime): the December 2026 staffing levels behind the 11 rules every sheet is judged against — four at the open, three at the close, five at 22:00, 14 on a Saturday and 10 on a Sunday, the ticket office in fixed pairs, and the rest (`currentRules`, `docs/proposals/tooling/report-data.mjs`). First relayed 27–28 Sep. Every sheet and the rules sheet say *confirmed verbally* | — | — |
| **FF18 reading — cadence or step?** | ✅ **Settled (owner, 28 Sep 2026, on ORR's text, 7.68): the CADENCE reading.** Standing on every weekly link; the step is reported beside it as information a design controls | — | — |
| **Proposals** | ✅ **Drawn — 9 sheets** in `docs/proposals/` (28 until twenty-one were withdrawn on 29–30 Sep 2026: the *By the Book*, *Same Turns* and *Pinned Turns* families, *Running Repair*, *Weeks 17-18 Swapped*, *Targeted Fatigue Redo*, *Three Mondays*, *Frozen Block*, *Tenth Sunday*, *Short Closer*, *Light Retime*, *Polished Clean*, *Cover at Seventeen*, *Saturday Four*, *Just Enough* and *Gates Mended* — and two added the same day), the first on 17 Sep 2026, the latest (Full Overhaul, of the Running Repair family) on 29 Sep; all of them in the managers' edition of 28 Sep, judged against one rule set; ⚠️ **none frozen** | T−8 weeks | The four decisions above are settled (29 Sep 2026), so freezing one now waits on the management review. The folder's `README.md` is the index; each sheet is eight pages, compared only with today's link, and lists its open questions on page 1 (*Still to settle*); `Proposals-Summary.pdf` sets all 9 side by side |
| **Management review meeting** | ❌ Not scheduled | T−6 weeks | **A date.** See below |

## The backwards plan — because the only immovable deadline is outside this repository

This document previously admitted *"the timing … is not known"*, and that was reasonable when it was
written. It is now **August 2026**, the target is **December 2026**, and a very sophisticated
technical project can still be rushed because nobody worked backwards from the date.

*(28 Sep 2026: the T−10 row — the four decisions settled — falls due in early October, not late
September as this table first said: ten weeks before a mid-December T is the first week of October.
**29 Sep 2026: all four are now settled** — the Sunday finish and FF18 on 28 Sep, the staffing
requirement and the contracted week on 29 Sep. See the dashboard above.)*

**T = the December 2026 timetable change date.** Pin T first — everything below is relative to it,
and T is a published industry date, not something to estimate.

| Milestone | Latest safe | For a mid-December T, that is roughly |
|---|---|---|
| Timetable source frozen | T−12 weeks | mid-September 2026 ✅ *(already done)* |
| The four decisions above settled | T−10 weeks | early October |
| First viable proposals | T−8 weeks | mid-October |
| Management review | T−6 weeks | end October |
| Adjusted proposals | T−4 weeks | mid-November |
| Operational sign-off | T−2 weeks | end November |
| Tool / data freeze | T−1 week | early December |

**These intervals are a starting proposal, not a commitment** — Gareth and Nathan should set the
real ones. The point is that a backwards plan exists at all: without one, the first hard date anyone
meets is the timetable change itself.

**If the room is booked before everything lands**, the useful minimum is unchanged: the baseline
table below, printed alongside the current link. That alone answers "where are we starting from",
which is the question a proposal is unreadable without.

---

## Why this exists

Nathan Sobers (Regional Manager, London Area) issued the three base simplifiers for the December 2026
timetable change and asked S. Silva and G. Miller to build CEA roster proposals for the wider team,
with dedicated days and a room booked. He will then assess the proposals against **business
requirements** and the **ORR good-practice fatigue factors** (p3 of *Good practice guidelines —
Fatigue Factors*, December 2021).

The Links workspace (`links.html`) was to be the tool those proposals were built in. *(28 Sep 2026:
in the event they were built by `docs/proposals/tooling` running the Links modules under Node, or
supplied as grids and imported, and the sheets are rendered by that tooling.)* This document
records what the timetable actually demands, what the tool can and cannot currently do about it, and
the order the work should be done in.

## Sources

| File | What it is |
|------|-----------|
| `Dec_26_10_of_13_SX_MYB_Simplifier.xlsx` | Marylebone arrivals + departures, **Mondays–Fridays** |
| `Dec_26_SO_MYB_Simplifier__Final.xlsx` | Marylebone arrivals + departures, **Saturdays only** |
| `Dec_26_Su_MYB_Simplifier__Final.xlsx` | Marylebone arrivals + departures, **Sundays** |
| `goodpracticeguidelinesfatiguefactors.pdf` | ORR, Dec 2021. The factor list is **p3** |

Each simplifier is one sheet (`MYB`): arrivals (train, origin departure, arrival at MYB, platform)
against departures (train, departure from MYB, destination, max CAO, diagrams). Headcodes beginning
`5` are empty-stock moves and are excluded from every count below.

---

## What the timetable demands (measured, not estimated)

**Demand = arrivals *and* departures, weighted by the length of the train** (owner, Aug 2026 —
this settles what was open question 1). Both halves matter: an arrival is a full detrain and an
departure is a dispatch, and a 9-car train is not the same job as a 3-car one either way.

Passenger movements at Marylebone — ECS excluded:

| | Movements | Cars | Shape | First → last |
|---|---|---|---|---|
| **SX** Mon–Fri | 311 (148 arr / 163 dep) | 1,756 | **Twin-peaked** — by movement 08:00, 17:00 and 18:00 tie (23 each); **by cars the evening wins**, 17:00 (140) / 18:00 (138) over 08:00 (127) | 00:01 → 23:57 |
| **SO** Saturday | 215 (105 / 110) | 1,266 | **Flat** — 11–15 per hour across 08:00–20:00; peak 10:00 on both measures | 00:10 → 23:57 |
| **Su** Sunday | 188 (91 / 97) | 1,059 | **Late-starting, evening-weighted** — nothing 01:00–07:00, peak 17:00 on both measures | 00:05 → 23:54 |

Hourly, both measures (arrivals + departures; hours 01–04 are empty on all three days and omitted):

```
hour        00  05  06  07  08  09  10  11  12  13  14  15  16  17  18  19  20  21  22  23
SX  movements 5   1  14  19  23  22  17  15  14  15  14  15  18  23  23  19  16  13  13  12
SX  cars     27   5  69 107 127 122  95  85  75  84  79  87 105 140 138 107  90  73  75  66
SO  movements 1   1   4  10  13  14  15  14  13  11  12  12  14  14  12  11  13  12  11   8
SO  cars      4   6  24  58  75  81  92  88  77  64  68  72  84  82  67  64  79  78  62  41
Su  movements 1   -   -   3   8  11  13  13  12  11  10  11  13  14  13  13  10  11  12   9
Su  cars      5   -   -  15  45  65  71  74  71  61  55  64  69  78  73  75  52  71  65  50
```

Three genuinely different shapes. The generator already separates Mon–Fri / Sat / Sun targets, so the
model fits — what changes is the distribution of duty start times inside the day, not the length of
the working day.

**Weighting by cars changes the weekday answer.** On movement count the morning and evening peaks tie
at 23; on cars the evening is 10% heavier (140 v 127) and the peak *hour* moves from 08:00 to 17:00.
The evening also stays high for longer — 17:00 and 18:00 are both above 135 cars, whereas no morning
hour reaches that level (08:00 is 127, 09:00 is 122). A design that staffs the two peaks equally is therefore under-covering the
one that matters more. Saturday and Sunday are unaffected: both measures agree on their peak hour.

**Where the length figures come from, and the one gap.** `Max CAO` (train length in cars, 3–9) is
present on **every** departure. An arrival and a departure on the same spreadsheet row share a
platform and a unit — the arrival turns round into that departure — so the row's `Max CAO` is the
arrival's length too; that covers 85–89% of arrivals directly. The `Unit Diag.` column recovers a
further handful by matching the diagram to a length recorded elsewhere in the sheet. That leaves
**21 SX / 11 SO / 10 Su arrivals with no length recorded anywhere**, counted at the day's mean
(6 cars) rather than dropped.

**A recovered length is capped at 9, the route maximum.** Where a cell listed two unit diagrams the
recovery summed them — right in principle, since the arrival splits into two departures — but it
produced three impossible values (11, 13 and 13 cars) against a `Max CAO` that never exceeds 9 in
the authoritative data. Capping them costs 10 cars across 4,081, and the peak hours are unchanged
except that Saturday's 10:00/11:00 tie by cars resolves to 10:00, matching its movement peak.

> **Do not default an unresolved arrival downward.** These are mostly trains that terminate and go
> empty to stabling, so nobody re-boards — arguably a *heavier* CEA job than a turnround, not a
> lighter one. Counting them at zero would quietly delete the workload the tool exists to show.

**Two corrections to the earlier figures in this plan.** First, five SX cells store their time as an
Excel serial fraction (`0.4034…` = 09:41) rather than as text, and the first parse dropped them —
three at 09:00, one at 16:00, one at 18:00. The SX totals are therefore **311, not 306**. Second,
`+` in a time (`05+46`) marks an **ECS** move, without exception: all 53 `+` movements carry a `5x`
headcode and all 306 `:` movements carry `1x`/`2x`. That rule is what the ECS exclusion rests on, and
it is worth restating because a parser that treats `+` as a separator silently inflates the weekday
day by 53 movements of work nobody does.

**Still not used: platform occupancy.** The `Plat.` column spans platforms 1–6 plus `1T`–`6T` variants
and `W`. Concurrent platform use is arguably closer again to what drives CEA *headcount* — two trains
on one platform is not the same job as two trains on two platforms — and nothing here computes it.
Recorded as a known limitation of the demand curve, not as a blocker.

**Resolved: all three simplifiers are final** (owner, Aug 2026 — open question 4). `SO` and `Su` are
named `__Final`; `SX` is named `10_of_13` and is not, which is why this was flagged — the weekday
profile drives most of the design. The naming is not the status: the content of the measured file is
settled. The file name stays on screen in `DEC_2026_SOURCE` regardless, because "final" means *this
file* is settled — if a later weekday file ever supersedes it, every figure here has to be
re-measured from that file rather than assumed to carry over.

## What actually drives CEA headcount (owner, Aug 2026)

Not the trains, mostly. The station rosters **posts** — ticket office, gateline, passenger assist,
lost property (daytime Mon–Fri only) — plus **extras to cover breaks**. A post is a continuous
commitment: the gateline needs someone on it whether the hour carries 23 movements or 5. So a large
part of the headcount is flat across the operating window and does not follow the train curve at all.

**The existing link already covers all of that**, which is why the existing link is the baseline for
December 2026 rather than something to be rebuilt from the timetable. See package 4.

**So the measured service above is EVIDENCE, not a target.** It is what the coverage overlay shows a
designer so they can judge whether cover looks right; it is not a number the tool turns into staffing.
There is no CEA-per-train ratio written down anywhere, and the tool must not invent one.
## The staffed window, and the one boundary that has to move

The CEA operating window is **Mon–Sat 06:20–23:55** and **Sunday 07:15–23:25** (owner, Aug 2026).
The railway day runs to the last train just past midnight; CEA duties finish at 23:55, so the
post-midnight departures are outside the link by design, not by oversight.

Measured against those real windows:

| | Inside window | Before | After |
|---|---|---|---|
| Mon–Fri | 300/311 — **96.5%** | 9: last trains 00:01–00:15, then 05:55 / 06:04 / 06:11 dep, 06:16 arr | 2 — both 23:57 |
| Saturday | 212/215 — **98.6%** | 2: 00:10 dep, 05:52 dep | 1 — 23:57 dep |
| **Sunday** | 182/188 — **96.8%** | 1: 00:05 dep | **5: 23:27 dep, 23:35 arr, 23:45 dep, 23:51 arr, 23:54 arr** |

**Mon–Sat needs no change.** The overhang is two minutes; the duty ends as the last train leaves.

**Sunday's finish looks ~30 minutes short.** Two departures (23:27, 23:45) and three arrivals (23:35,
23:51, 23:54) all fall after the 23:25 finish. Sunday's *start* is fine — the first three Sunday departures are all at or
after 07:15. **SETTLED (owner, 28 Sep 2026): no duty runs past 23:25 on a Sunday — agreed practice, and it stays so.** The five
later movements are recorded on the sheets as a known fact, not an open question.

---

## The fatigue factors, against what the tool checked — the gap that package 2 closed

> **This table is the ORIGINAL gap analysis, kept as the record of WHY package 2 was built.** Its
> "Checked today?" column describes the tool **before v19.46**; every row in it now reads yes. Do not
> read it as current state — `links-fatigue.js` covers every applicable factor and asserts the
> inapplicable ones. It is left here because the argument for the work is more useful than a table
> of ticks, and because the "Applies to a CEA rotating link?" column is still the live judgement.

The sheet lists **25 rows** in six families (read at source Aug 2026; this said 24 against a panel rendering 23, and the real answer was neither). `runDesignChecks` tested two things that map to
them, and CEAs work no nights, which makes a large part of the list inapplicable:

| Factor | Applies to a CEA rotating link? | Checked today? |
|--------|--------------------------------|----------------|
| FF2 early start 05:00–07:00 | **Yes** — every 06:20 duty is an FF2 early | No |
| FF15 >4 consecutive early shifts in a rotating pattern | **Yes** | No |
| FF8b <2 days rest after a block of consecutive early starts | **Yes** | No |
| FF19 successive start times vary by >2h | **Yes** | No |
| FF17 backward rotating pattern | **Yes** — the generator builds forward; a check would prove it | No |
| FF18 rotating pattern of about a week | **Probably** — the link moves one line per week; worth asking Nathan | No |
| FF11 >13 consecutive shifts without a 48h break | Yes | Partially — "longest run" is related but is not this |
| FF13 <12h rest in any 24h | Yes | **Yes** — the short-turnaround check |
| FF5 / FF7 duty over 12h (day) / over 10h (early) | Yes | No |
| FF10 >4 consecutive 12h day shifts · MRSF >12 consecutive day shifts · >7 consecutive 8h shifts · >55h in any 7 days | Yes | No |
| FF1, FF3, FF4, FF6, FF8, FF9, FF12, FF14, FF16, FF20, MRSF permanent-pattern rules | **No** — all night-shift or pre-05:00 rules | n/a, but a check should assert they stay n/a |

The gap was the point: Nathan assesses against this list, and the tool covered two of it. Closed at
v19.46 — see package 2 below for what the building actually found.

### The checks card now has TWO halves, and the difference matters in the room (v19.80–v19.94)

Everything above is the **advisory** half — the ORR's p3 factors, which the ORR is explicit are *not*
prescriptive limits. That half reports what a design features and never passes or fails it.

Sitting **above** it is a second, smaller section from `links-limits.js`: the **hard limits**, which a
design either meets or cannot be run. It renders in red on a breach, and it renders whether it passes
or fails — a passing limit has to be visible on the sheet that goes to Nathan, not hidden behind a
disclosure. Today it holds one check: **no more than 13 consecutive worked days**.

**Where that 13 comes from, since the question will be asked.** The Hidden report into the Clapham
Junction crash of 12 December 1988, whose working-hours recommendations the industry adopted as
standards; at Chiltern they are carried in **company policy** (owner, Aug 2026). It is not
legislation, and the app is careful never to say it is — that claim was made in error at v19.80 and
took an external review to unwind.

**Three more limits in that family exist and the tool does not yet treat them as limits.** They are measured
already; they are simply rendered as advisory ORR rows:

| Limit in the Hidden family | Measured by | Shown today as |
|---|---|---|
| Max consecutive days (13) | `assessHardLimits` | **hard limit** |
| Min rest between turns | the short-turnaround check (12h) | FF13, advisory |
| Max length of a turn | duty length (12h) | FF5, advisory |
| Max hours in a rolling week | `maxHoursInAny7Days` | MRSF row at 55h, advisory |

Worth settling before a proposal is frozen, because it changes how a reader weighs those rows: a
figure in the advisory half invites a justify/minimise/control conversation, while the same figure in
the hard half ends one. The blocker is the confirmed figures from the policy document, not the code.

## Baseline: what the CURRENT link scores (review pass)

The first draft proposed fatigue checks without ever running the existing checks against the existing
link. That was the wrong order — you cannot read a proposal's numbers without knowing what today's
pattern scores, and Nathan will inevitably ask. Measured by running `runDesignChecks` over the live
`weeklyRoster` and `bilingualRoster`:

| Cycle | Lines | Longest worked stretch | FF11 — longest run between 48h breaks | Short turnarounds (<12h) | Weekends off |
|-------|-------|------------------------|----------------------------------------|--------------------------|--------------|
| **Main — the comparator** | 20 | **9 days** | **12 shifts** — clear | **0** | 4/20 (20%) |
| Bilingual — context only | 8 | **8 days** | **15 shifts** — over | **0** | 0/8 |

**The MAIN row is the comparator, and since v19.98 it is the only one.** The 22-line design *(28 Sep 2026: 24 lines since v20.01)* replaces
the main 20-line cycle and does not take on the bilingual roster's work, so a bilingual figure is no
longer a like-for-like anything. The row stays because it is a measured fact about a rotation these
staff still work, and because its structural cause (below) is the clearest worked example in this
document of why a spare week is not a 48h break. The workspace's own baseline panel now shows main
only, with a clause naming what it is a comparator FOR — an unexplained missing row reads as an
oversight.

> **These figures were 15 / 14 / 15 / 15 until v19.79, and they were wrong.** The tool counted a
> SPARE week as seven worked days. A spare week is **four** duties of seven (owner, Aug 2026) — you
> are marked spare on all seven because you are available for cover, but four is what you work — so
> the week always contains a rest day and can never fuse the blocks either side of it. Counting it
> 7/7 did exactly that, and inflated both cycles by six days.
>
> The direction is what makes it serious rather than untidy. **13 consecutive days is CHILTERN's
> roster limit**, carried in company policy (owner, Aug 2026); its ORIGIN is the standard the
> industry adopted after the Hidden report into the 1988 Clapham Junction crash, and **that standard
> was withdrawn in 2007** — cite it as an origin, never as a current requirement (v19.96, external
> review). So a check reporting 15 was not erring on
> the safe side: it reported
> a breach that does not exist, on the roster people are working right now. Anyone who knows the
> real link would have discounted the row — and the next design that genuinely does go past 13
> would have been hidden by that discount. Both figures above are now the WORST CASE over every
> placement of each spare week's four duties, which is the number that can be defended in the room.

**Those first two columns are DIFFERENT measures, and the corrected figures make the gap wider,
not narrower.** A single rest day is not a 48h break, so it does not reset the FF11 count — the
main cycle's 9-day worked stretch sits inside a 12-shift FF11 run, and the bilingual's 8-day
stretch inside a 15-shift one. Quote the **FF11 column** when the subject is FF11; that is the one
being read against the guidance. Quote the worked-stretch column when the subject is consecutive
days on duty.

Two things fall out of that, and both matter more than anything else in this document:

1. **The BILINGUAL cycle exceeds FF11; the main cycle does not.** 15 shifts against 12. That is a
   different statement from the one this document carried until v19.79 ("both cycles, at 15 shifts
   each"), and a more useful one: it names where the problem actually is. A standby day IS a duty
   and counts, but a spare WEEK is four of them, not seven. Read any FF11 finding in a proposal
   against 12 for main and 15 for bilingual, never against zero.
   **The bilingual 15 is a worst case with a structural cause worth knowing:** its two spare weeks
   are lines 1 and 8 of 8, so they wrap into each other, and a spare week's three rest days need
   not be adjacent — so in the worst arrangement neither week supplies a 48h break while both still
   supply duties.
2. **Zero short turnarounds on either cycle.** The existing link never places a timed late immediately
   before a timed early — the same "start times only move later" principle the generator encodes. The
   FF13 check is therefore silent on live data, which is a good sign for the check rather than a
   worrying one: it is not crying wolf today, so when it does fire in a proposal it will mean
   something.

**A caution about how that was measured, which the v19.98 change makes moot and worth keeping
anyway.** Splicing the 20 main lines and the 8 bilingual lines into one 28-line sequence returns a
longest stretch of **19** — an artefact of joining two unrelated rotations end to end, not a property
of either. The numbers above are per real cycle. The tool will happily compute a stretch across
however many lines it is given, so a design's figures only mean something once those lines genuinely
are one rotation. The 22-line design *(28 Sep 2026: 24 lines since v20.01)* is one rotation by construction; the point survives as the
general rule.

## What the generator produced from today's roster seed (v20.02)

**Refused since v20.98, and no longer the default.** The contract gate refuses this seed — today's
duties do not fill a contracted week across a 24-line rotation (below) — and since v21.00 the
workspace opens on the December 2026 default table (`links-default-targets.js`) instead. The table
here is the record of what the roster seed produced, not what the workspace ships.

**Measured at 24 lines / 4 spare weeks (v20.02).** The seed is the main cycle only — **18 slot
rows and 4 spare weeks**, taken from the roster with nothing invented — but each row at its BUSIEST weekday, so it
carries 60 weekday duties where today's link works 58 (78 a week against 76). (v20.01 briefly
seeded 5; see the FF11 note below for why that was reverted.) Earlier measurements — v19.75 at 28/6,
v19.98 at 22/4, v20.01 at 24/5 — are superseded and are not quoted here, because a figure from an
old shape sitting beside one from the new is how a table stops being readable.

Everything below was the default at the time: settled construction, all **six** line-order objectives on (v20.02 added the run cap), re-measured after the v20.02 spare-spread fix.

| | live main roster (20 lines) | generated, settled (24/4, roster seed) | generated, rotating (24/4, fallback) |
|---|---|---|---|
| longest worked stretch | 9 days | **8 days** | 8 days |
| FF11 (shifts between 48h breaks) | 12 | **11** | 11 |
| short turnarounds | 0 | **0** | **0** |
| weekends off | 4/20 (20%) | **9/24 (38%)** | 9/24 (38%) |
| long weekends (3+ days) | — | **7** | 8 |
| longest block on one shift type | 3 | **3** | 3 |
| week-to-week step, mean / worst | 4h 00m / 8h 46m | **2h 36m / 7h 26m** | 0h 47m / 2h 27m |
| boundaries over 2h (FF18) | 9 of 20 | **6 of 24** | 1 of 24 |
| cover weeks — gaps between them | — | **6, 6, 6, 6** | 6, 6, 6, 6 |
| hard limit — 13 consecutive days | met (9) | **met (8)** | met (8) |

Both columns were re-measured together after the v20.02 spare-spread fix, so nothing here is a
figure from an older shape sitting beside a newer one. The row previously labelled FF19 is corrected
to **FF18** — the between-lines factor those numbers have always come from.

### The design is five hours a week short of contract, and nothing showed it until v20.04

*(28 Sep 2026: this heading and the paragraph below said "six". 35h − 29h 53m is **5h 07m** on the
measure stated here; six was 123h ÷ 20 working lines, the pre-v20.98 measure.)*

**The measurement.** Excluding Sundays — which are not contracted for any grade here — and averaged
over every line of the rotation, with each spare week counted as a full contracted week (v20.98):

| | working lines | hours a week each |
|---|---|---|
| live main roster (20 lines / 4 cover) | 16 | **35h 00m** — exactly the contract |
| generated 24 lines / 4 cover | 20 | **29h 53m** (refused since v20.98) |

The live roster landing on 35.00 to the minute is the check on the measure: the roster is built to the
contract, so anything else would mean the yardstick was wrong before any design was judged by it.

**The gap is arithmetic, not a fault in the design.** The seed is today's duties — 18 shift rows, 78
timed duties a week as the seed counts them (each row at its busiest weekday; today's link actually works
76) — and widening the link from 20 lines to 24 spreads them over 20 working lines
instead of 16. Same work, more people, less each. It is the same counter-intuitive effect as the cover
weeks below, one step further on.

**So it is a question for the room, and a sharp one.** Either the December 2026 service adds enough
work to fill about five hours a week per person (5h 07m) — in which case the targets should be seeded from the new
timetable rather than from today's roster — or the widened link does not fill a contracted week and
something has to give. The tool now states the figure on screen and on the printed sheet; it does not
answer which.

Sundays are reported separately rather than hidden: **8 Sunday duties, 68h 15m across the rotation**,
on top of the figures above. They are real work and real pay; they are simply not part of a comparison
against a contracted week.

### A spare week does not add capacity — it takes a line out of the pool

Worth taking into the room, because it is counter-intuitive. **A spare week removes a line from the
pool that carries the duties.** The work is unchanged at **76 timed duties a week** (today's link, counted day by day — the seed's 78 counts each
shift row at its busiest weekday), so each extra cover week is paid for in rest days on everyone else:

| | working lines | duties per working line | rest days |
|---|---|---|---|
| live main roster (20/4) | 16 | 4.75 | **2.25** |
| 22 lines / 4 spare (v19.98) | 18 | 4.22 | 2.78 |
| 24 lines / 5 spare (v20.01, reverted) | 19 | 4.00 | 3.00 |
| **24 lines / 4 spare (chosen)** | **20** | **3.80** | **3.20** |

So the widening to 24 is a large gain on today's roster: **2.25 → 3.20 rest days** per working line
and weekends off from 20% to 38%. The v20.01 fifth cover week would have spent about **0.2 of a rest
day per working line** to buy one more standby week — a legitimate trade, taken and then reverted
once its motivating finding turned out to be a bug (below).

*(28 Sep 2026: that gain holds only for today's 76 duties spread over 24 lines — the roster seed,
refused since v20.98. The 23 proposals carry **94–98 timed duties a week**, ≈4.70–4.90 per working
line and so ≈2.1–2.3 rest days, about today's 2.25; and they give **2–6 weekends off in 24**, not 9.
On the proposals' own figures the widening carries more work rather than buying rest.)*

**The v20.01 FF11 finding was a BUG IN THE ORDER OPTIMISER, found and fixed at v20.02.** It was
recorded here as a property of running five spare weeks — measured across lengths 22–25, every
configuration with 5 tripped FF11 and 4 and 6 did not. That measurement was real and the conclusion
was wrong. `generateLink` spreads the cover weeks evenly (gaps 5, 5, 5, 4, 5 at 24/5); the **reorder
was clustering them**, returning gaps 9, 3, 1, 7, 4 with two adjacent — and two adjacent spare weeks
chain into one long run. FF11 went 9 → 14 purely from the ORDER. An even spread is now charged
unconditionally in the optimiser and FF11 comes back at **11**.

Worth stating plainly for the room: the tool briefly reported a fatigue finding that was its own
doing. That is the failure mode this workspace's rules are written around, arriving from the one
direction nobody had guarded — the reorder was assumed to only ever make things better, because
every objective in it was a preference. It can make a design worse than the one it was handed.

**The run cap does not always reach its target, and the reason is a decision for the room.** The
"Most shifts in a row" box defaults to **6**. With that switch on alone the reorder reaches 6; with
the full set on it reaches **8** on the roster seed (the shipped December default reaches 7, with 5
of 24 weekends off — `docs/proposals/tooling/default-baseline.mjs`), and the status line says so rather than letting the box imply a
guarantee.

It could be made to reach 6 with the full set on. Re-measured after the spare-spread fix — the
earlier figures here were partly that bug talking:

| weight on the run cap | longest run | full weekends off |
|---|---|---|
| **40 (shipped)** | **8** | **9 of 24** |
| 100 | 7 | 7 |
| 150 / 200 / 300 / 600 | 6 | 5–6 |

**The cost of reaching 6 is three to four full weekends off across the rotation.** A longest run of 8
sits well inside the 13-day company limit, so 40 is kept — but that is a judgement about what staff
would rather have, not a technical finding, and it is exactly the kind of thing to put in front of
the room rather than settle in code. (FF11 across those weights reads 11, 11, 9, 16, 9, 10 — a
heuristic optimiser landing in different local minima, so no FF11 figure there is a property of the
weight and none is quoted as one.)

**Correctness, verified rather than assumed** (v19.75). Against the real seed, both constructions:

- meet every day's total **exactly** — Sun 10, Mon–Fri 16, Sat 14, matching the seed *(28 Sep 2026:
  those were the v19.75 seed's totals; the v20.02 main-only seed is Sun 8, Mon–Fri 12, Sat 10 —
  `buildRosterTargets` in `links-seed.js`)*;
- staff every individual shift TIME at exactly the right level on every day, not merely the totals;
- fill every line, none blank;
- produce **0** short turnarounds;
- and reordering for the line-order objectives leaves the daily coverage multiset **identical**,
  which is the safety property the whole objectives feature rests on.

The generator also **refuses** rather than degrading when the targets exceed capacity — see the
capacity table under package 4, which is where that stops being a curiosity and starts being the
argument.

## Work packages

Ordered **2 → 1 → 3 → 4 → 5**: the fatigue checks carry the most value and depend on nothing, and
the operating window is what unblocks the overlay and the generator targets. The numbering is kept
from the first draft so the review correction under package 1 stays legible.

**Status:** 2 shipped v19.46 (with the baseline), 5 shipped v19.47, 1 shipped v19.54, 3 shipped
v19.56. **4 was declined** (owner, Aug 2026 — a control built at v19.78 was removed at v19.83; see
package 4). Nothing in this list remains open.

### 1. Operating-window setting — ✅ **SHIPPED v19.54**

`links-window.js` + `links-window.test.mjs`. The window is editable on the Coverage card, persisted
per design, shown above the heat map, stated on both compare column headers and on the printed
sheet, and defaulted for every design saved before it.

**The reason turned out to be stronger than this plan recorded.** The heat map derived its own span
from the design — first worked hour to last — and flagged a gap only strictly *between* them. So
missing cover at either END of the day was invisible: the span simply shrank to fit and those hours
left the table. Measured on a 28-line design where everybody finishes at 14:20, leaving the station
unstaffed until the 23:55 close: **zero gaps flagged**. It now flags **71**. The window did not just
make the demand overlay expressible — it fixed a blind spot in the check that already existed.

Two things worth knowing before changing it: `normaliseWindow` falls back per ROW but never per
FIELD (pairing a stored start with a default end would invent a window nobody chose and then print
it as deliberate), and the editor uses TEXT inputs because Chromium renders `<input type="time">` in
the OS's 12-hour format **even at en-GB** — measured — which would have put "11:55 PM" beside a grid
reading 23:55.

<details><summary>Original scope</summary>


Store the window **on each design**, with app defaults of Mon–Sat 06:20–23:55 and Sun 07:15–23:25.

Per-design rather than global because a proposal may legitimately test a moved boundary — the Sunday
finish is the live example — and compare mode then shows two designs with different spans side by
side, which is the argument you would put to Nathan. It also travels with the design when printed, so
the sheet states the window it was designed to. Designs saved before this carry no such field and
fall back to the defaults, so nothing already saved changes.

Two rows (Mon–Sat, Sun) matches the operation as described. Saturday can split from Mon–Fri later if
it ever diverges; the generator already has three columns, so the plumbing exists.

**The trap in making it per-design:** compare mode highlights differing *cells*, not differing
*windows*, so two designs built to different spans would compare as though they were like for like.
If the window is per-design, compare mode has to show it in both column headers, and the printed sheet
has to state it. Otherwise the override becomes a way to make an unfair comparison look fair.

**Correction (review pass).** The first draft of this plan put this package first, on the claim that
"packages 2–4 all consume it". That is wrong. Package 2 does not touch it at all: FF2 needs start
times, FF5/FF7 need durations, and FF15/FF8b/FF19/FF17 need the day sequence — none of them need to
know when the station is staffed. Only the demand overlay (3) and the generator targets (4) consume
the window. With the false dependency removed there is nothing holding package 2 back, and package 2
is the one Nathan will actually assess against, so it goes first.

Note it needs a `firestore.rules` allowlist change — the same shape as the `deletedAt`/`deletedBy`
pair added at v19.41 — so a rules deploy rides alongside hosting.

*Done when:* the window is editable, persisted per design, shown on the Coverage card so the heat map
explains itself, printed on the sheet, and defaulted for existing designs.

</details>

### 2. Fatigue checks against p3 — ✅ **SHIPPED v19.46**

`links-fatigue.js` + `links-fatigue.test.mjs`, rendered in the Design checks card. The baseline
below ships with it. What it found on the live link the day it landed is recorded in "Baseline"
above; the two design notes that survived contact are that FF11 needed its own rule (a single rest
day is not a 48h break) and that a rotation with **no** 48h break anywhere has to report every
worked day rather than the sequence length — the first implementation returned the length, counting
rest days as shifts, and its own test caught it.

Settled 28 Sep 2026 (owner, against ORR's *Managing rail staff fatigue*, Aug 2024): MRSF's 7×8h reads
eight hours or more, FF17 is ORR's own definition, FF18 is ORR's cadence factor (standing on every weekly
link, the step kept as information). **FF19 alone still renders "(definition to confirm)"**: the owner's
reading (a rest day resets it) is more lenient than ORR's wording, and the assessing manager should see
that.

<details><summary>Original scope</summary>


Extend `runDesignChecks` to cover every factor in the table above that applies, each labelled with its
FF number, so a printed proposal is already annotated against the document it will be assessed with.

The maths belongs in `links-design.js` (pure, tested) — the module already holds the turnaround and
consecutive-run logic, and this is the same kind of reasoning over the same sequence.

Three design notes, the third added in the review pass and the most important of the three:

- The n/a factors should be *asserted* rather than silently omitted, so a design that somehow acquires
  a night duty fails loudly.
- The checks report factors **present**, not pass/fail — the ORR framing is explicitly that these are
  not prescriptive limits, and a tool that renders them red/green would misrepresent the guidance.
- **Separate standing characteristics from design-specific findings.** FF2 fires on *every* 06:20
  duty, so on this link it is a property of the operation, not a signal about a proposal — and a check
  that flags half the rotation on every design is the same cry-wolf failure this plan warns about for
  the demand overlay. Present the unavoidable factors as a stated characteristic with a count; reserve
  the per-design findings for the factors a designer can actually change (FF15, FF8b, FF19, FF11, the
  duty-length and weekly-hours rules).

**Liability posture — state this in the UI, not just here.** These checks are an aid to two designers,
not a fatigue risk assessment. The greatest risk in this package is not a missing check but a design
that shows no findings and is read as approved: false assurance on a safety-adjacent matter is worse
than no tool at all. Nothing in the output should read as a certificate, and the ORR's own escalation
— justify, minimise, then assess and control — is the frame to present findings in.

*Done when:* every applicable factor is reported with its FF number, the inapplicable ones are
asserted, and each rule has a unit test.

</details>

### 3. Demand overlay on the coverage heat map — ✅ **SHIPPED v19.56**

`links-demand.js` + `links-demand.test.mjs`. Three demand rows sit under the cover in the same
table, one per day class, shaded in orange against their own peak — cars per hour, arrivals plus
departures, per the answer to open question 1. The note names the disagreement between the two
measures (08:00 by movement, 17:00 by cars), states the uncovered staffed hours as a finding, states
the movements outside the window as a fact, and carries the timetable's provenance.

**It shipped broken once, and the failure is worth keeping.** The first implementation held HOURLY
buckets and asked the window an hourly question. The Sunday finish is **23:25**, so "is hour 23
staffed" is true — and the five movements after it, the one live finding in this whole plan, were
reported as fully covered. Every unit test passed: one of them was written with a synthetic
`h <= 22` Sunday window rather than the real one, so it agreed with the bug. It was caught by
rendering the actual page and reading the actual sentence.

The fix stores movement TIMES rather than hourly buckets — and derives the hourly curve from them,
so the shading and the boundary check cannot describe different timetables. That also made the
mirror-image finding visible at the other end of the day: **three weekday trains (06:04, 06:11,
06:16) run in the hour before the 06:20 opening** — the ones the overlay can mark, since they share
an hour cell with the opening. A fourth, the 05:55 departure, is earlier still and sits in an hour
the heat map does not draw at all; the window table above counts all four. Quote four, not three,
if the subject is how much of the morning falls outside the link.

### 4. More people, same shape — ❌ **WON'T-DO (owner, Aug 2026: "over complicates it")**

A control was built at v19.78 — "increase every target by N%" on the generator, scaling the seeded
target table in place — and **removed at v19.83**. The uplift figure was never supplied, and on
reflection the tool did not need to own this: the targets are hand-editable, so a designer who knows
the number can simply type it.

**The measurement behind it stands, and it is the part that matters.** It is not a feature request,
it is the argument to take into the room:

> 22 working lines × 7 days = **154 day-slots per cycle**. Every extra duty comes out of a rest day.

| uplift | duties | rest days | rest days per line |
|---|---|---|---|
| 0% (today) | 104 | 50 | 2.27 |
| +20% | 124 | 30 | 1.36 |
| +25% | 129 | 25 | **1.14** |
| ~+37% and up | — | — | **refused: over capacity** |

*(28 Sep 2026: the +20% row read 107 / 47 / 2.14, which is +3%. Recomputed the way the other rows
are, rounding each day's total — Sun 12, Mon–Fri 19, Sat 17 = 124 duties, 154 − 124 = 30 rest
days, ÷ 22 = 1.36; the same rounding gives +25%'s 129. The table is the 28-line /
6-spare design of that time: 22 working lines, seed Sun 10 / Mon–Fri 16 / Sat 14.)*

**A service increase of any size cannot be absorbed by making the existing lines denser — the link
has to get bigger, which means more staff.** The generator refuses outright above ~+37% (28 people
needed on a weekday against 22 working lines), so the tool fails loudly rather than quietly producing
something unworkable.

*(The run-length column that used to sit in this table has been dropped: it was measured before
v19.79 corrected the spare-week reading and overstated by about six. The shape of the finding — every
extra duty costs a rest day — is unaffected, and is what the table is for.)*

If a percentage control is ever proposed again, `.claude/rules/links-design.md` records the two rules
it must carry, both of which cost a release to learn.

### 5. Midnight-crossing guard — ✅ **SHIPPED v19.47**

`endMinutesAbs` in `links-design.js` is now the one reading of a duty that runs past midnight, and
both callers use it: the heat map counts a wrapping duty on **both** days (Saturday spilling round to
Sunday) instead of dropping its post-midnight hours, and the turnaround check lets that duty eat into
the rest that follows it. `dutyMinutes` delegates to it rather than keeping a third copy — it now
lives in `links-design.js`, and `links-fatigue.js` re-exports it.

What the two defects had in common is the part worth remembering: **both erred towards *safer than
the truth*.** The heat map lost hours from the artefact whose entire job is showing where cover is
thin, and the turnaround check reported ~26h of rest for a 00:30 finish before an 06:20 start — 5h50
in reality — so the most dangerous turnaround the module can express was the one it called compliant.

Still unreachable from the CEA link (duties finish 23:55) and the `normaliseCustomShift` ban on a
wrapping value stays — it is the input boundary, not a duplicate of this. Reachable only through
legacy/imported data, the same route `canonicaliseShift` exists for.

## Not building

**An automatic optimiser.** The generator produces a compliant skeleton; which duties fit the service
is a judgement for the two designers. The tool's job is to check and to show, not to decide.

**~~Compare mode carrying its own analysis.~~ BUILT v24.25** (`links-compare-analysis.js`), once the
22 proposal sheets existed to build it against: cover against the service, hard limits and fatigue
factors for both designs, under the difference strip. The reasoning for deferring it is kept below.
Compare showed two grids with a gold cell diff; the
Coverage and Design-checks cards below described only the ACTIVE design. So the reason you would
compare two proposals — their cover against the service, their fatigue findings — was the one thing
compare mode did not do, and the cell diff told you *where* they differed rather than *what that
meant*. **Deliberately deferred, not rejected:** it was a real gap, but a feature rather than a
polish item, and it was to be built once there were two real proposals to compare, instead of against
a guess about what the comparison ought to say. (Related, and already recorded as accepted: at 1440px
both compare columns clip before Saturday, so Saturday cannot be compared without scrolling each
column on its own.)

**The generator's near-identical rows.** Seeded from the current roster it rendered 28 shift rows ×
3 columns = 84 number fields while the seed spanned all 28 roster lines — since v19.98 it is 18 rows
(the roster seed, main cycle only) or 19 (the December default) — most of them zero, so reshaping one
part of the day means finding one row among many similar time dropdowns. Left alone on purpose while package 4 might still change where those
targets come from, since re-designing the table first would have meant doing it twice. *(28 Sep
2026: package 4 was declined, so that reason for waiting has lapsed.)* (It said 25/75
until v19.65; the seed takes every distinct worked time across all 28 roster lines, and
`.claude/rules/links-design.md` already said 28 — the two docs simply disagreed.)

## Open questions

Ordered by how much they change if the answer is unexpected.

1. ~~**What actually drives CEA workload?**~~ — **ANSWERED (owner, Aug 2026): arrivals as well as
   departures, weighted by the length of those trains.** Computed and recorded in "What the timetable
   demands" above; it moves the weekday peak from 08:00 to 17:00, which is a material change to what
   packages 3 and 4 are built against. Platform occupancy remains uncomputed — a known limitation of
   the curve rather than an open question, since the signal that was going to be settled has been.
2. **FF18 still needs raising early — but the earlier framing here was wrong** (owner correction,
   Aug 2026). This plan previously said the factor was "unavoidable by construction" because a
   28-line link moves everyone one line per week by design. That reads the factor as being about the
   weekly *cadence*, when the concern it names is the **size of the step**: what makes a weekly
   rotation hard is your working day jumping, and a rotation where consecutive lines sit close
   together asks far less of the body clock than one where they do not. The cadence is fixed; the
   step is a design choice, and a real one.

   Two consequences. First, it is still worth settling with Nathan before a proposal is frozen —
   if the factor is read as cadence-only then no proposal can avoid it, and that belongs in the
   justify/minimise/control conversation rather than a checklist. Second, the step is now
   **measurable and tunable**: `links-adjacency.js` (v19.58) scores the week-to-week movement across
   the whole rotation and the generator can order the lines to minimise it, behind a switch.

   **Do not quote a step figure without saying which switches were on** (corrected v19.65). This
   paragraph said "took the mean step from 42 minutes to 9", which is `gentle` **alone** and is not
   what the tool does by default. Since v19.60 `variety` is also on, and it deliberately spends that
   step to cap how long anyone sits on the same shift — the change made after 11-week blocks were
   judged "excessive and would be unpopular". The delivered default measures **95 min** on the roster
   seed. Nine minutes is achievable and is a real answer to FF18; it is just not the one the tool
   gives you unless you turn variety off and accept blocks of 8+. Offering the 9 in the room would
   overstate the tool by an order of magnitude.

   **The panel row now reads from that measurement** (v19.69; it reported a hardcoded `standing`
   from v19.46, breaking the module's own "never hardcode a status" rule for the second time after
   FF13 at v19.48). It states the typical weekly move, the largest, and how many boundaries exceed
   two hours. **On the live main roster: typically 4h 0m a week, largest 8h 46m, 9 of 20 boundaries
   over 2h** — the baseline to read any proposal's figure against, and the number to take into the
   conversation below. For comparison the workspace's December default, generated with every
   line-order objective on, measures typically 4h 16m, largest 8h 37m, 8 of 24 over 2h
   (`docs/proposals/tooling/default-baseline.mjs`).

   The STATUS deliberately stays `standing` whenever the step is measurable rather than turning
   `present` above some figure: the ORR gives no threshold for FF18, so inventing one would be the
   pass/fail rendering this panel must never produce. The derived branch is `n/a`, for a design with
   no timed lines at all — a row that cannot be computed does not get to claim anything.
3. ~~**Does the Sunday finish move?**~~ — **ANSWERED (owner, 28 Sep 2026): no. No duty runs past 23:25 on a Sunday; agreed
   practice.** The record: five movements fall after 23:25 — and the answer to question 1
   **strengthens** this rather than weakening it. The earlier draft noted the case would drop from
   five movements to two if arrivals needed no CEA; arrivals do count, so all five stand: 23:27 dep,
   23:35 arr, 23:45 dep, 23:51 arr, 23:54 arr. Three of those five are arrivals full of people
   getting off at an unstaffed terminus.
4. ~~**Is the weekday simplifier final?**~~ — **ANSWERED (owner, Aug 2026): yes, all three are final.**
   The `10_of_13` naming on the weekday file is not a status. This unblocked package 4 (later declined), which had no
   business being built against a timetable about to be reissued. `DEC_2026_SOURCE.provisional` is
   cleared and the coverage card no longer says "(provisional)".
5. **Should Saturday's window ever differ from Mon–Fri?** Currently identical; the setting can split
   them if the answer changes.

## Proposals drawn (8 Sep 2026 onward)

**9 sheets** in `docs/proposals/` (28 until twenty-one were withdrawn on 29–30 Sep 2026, with Full Overhaul added), whose README is the index, each with an identity that survives a
meeting: a name, a code, and a fingerprint of the cells. On 28 Sep 2026 the 23 then drawn were re-issued as the
managers' edition (the two added that day, Familiar Nine and Just Enough, were made in it) — standalone, in plain English, and judged against **one rule set**: the 11 December
2026 rules (`currentRules`, `docs/proposals/tooling/report-data.mjs`). Every figure in a sheet is
computed from the cells it shows, and an independent recount of every sheet on 28 Sep agreed with every one.

| Family | Sheets |
|---|---|
| Same Turns | Same Turns, Quarter To, Weekend Capped |
| By the Book | By the Book, Eight Forty, Office Written In |
| Pinned Turns | Pinned Turns, Round Times |
| Right Away | Right Away and Familiar Nine — both meet all 11 rules (today's link meets 4 since the ticket-office helper rule of 28 Sep 2026; 3 before it) |
| Fifteen Turns | Fifteen Turns, Gates Mended, and Just Enough (28 Sep 2026) — Fifteen Turns with the fewest cells changed that meet all 11 rules: 29, proven the minimum |
| Weekday Lates | Weekday Lates and eleven variants of it |

Where each one stands on the same figures is page 9 of any sheet. **The first two, as drawn on 8 Sep**,
bracketed the choice as it looked then: *Same Turns* kept 15 turns people work today; *By the Book*
met every rule then in force and none of its turns was familiar. Against the 11 December rules it
meets 5 of 11. Both inherited today's Sunday window (open question 3).

## The four decisions, as they would be put in the room

A draft, written v21.97 so the questions exist in a form somebody can answer rather than only as
rows in a readiness table. **The point of each is the same: state the measurement, state what turns
on the answer, and do not offer a recommendation the tool has no standing to make.**

Everything below is already in this document; this section adds no facts. It exists because a
question spread across a plan is not a question anyone has been asked.

---

**1 · The Sunday finish.** *Does the staffed window on a Sunday move past 23:25?*

> **Answered (owner, 28 Sep 2026): no.** No duty runs past 23:25 on a Sunday; that is agreed
> practice and will remain so. The question is kept below as it was asked.

Five December 2026 movements fall after it: 23:27 dep, 23:35 arr, 23:45 dep, 23:51 arr, 23:54 arr.
**Three of the five are arrivals** — trains full of people getting off at a terminus with nobody on.
That the arrivals count is the owner's own answer to what drives CEA workload, so this is not a
question about whether they matter.

*What turns on it:* the operating window is stored per design, so a proposal can be built to either
answer — but not to both, and the coverage assessment differs throughout. It has to be settled
before proposals are frozen, not after.

*What the tool will not do:* decide it. The heat map marks post-window movements as a neutral fact
rather than a finding, deliberately, because a shut station is not a coverage hole.

---

**2 · FF18 — cadence, or step?** *Which reading of the ORR's "rotating pattern of about a week" is
being assessed against?*

> **Answered (owner, 28 Sep 2026, on ORR's text, 7.68): cadence.** FF18 is standing on every weekly
> link, and the step is reported beside it as information. The question is kept below as it was asked.

Read as **cadence**, no link can avoid it: a link moves everyone one line a week by construction.
Read as **the size of the step** — how far your working day jumps week to week — it is a design
choice, and a measurable one.

*The measurements, and quote them with the switches named:* the live main roster moves **typically
4h 0m a week, largest 8h 46m, with 9 of 20 boundaries over two hours**. The workspace's December
default measures **typically 4h 16m, largest 8h 37m, 8 of 24 over two hours**. A step of ~9 min is reachable but only by turning the variety
constraint off, which produces blocks of 8+ weeks on the same shift — judged "excessive and would be
unpopular" by the owner, so it is not an answer to offer.

*What turns on it:* under the cadence reading no proposal can clear the factor, and it belongs in
the ORR's own justify / minimise / control conversation instead of on a checklist. Under the step
reading the proposals should be compared on the figure, and the tool already produces it.

---

**3 · The contracted week.** *Today's duties cannot fill a 24-line link. Where does the rest come
from?*

> **Answered (owner, 29 Sep 2026): from the December 2026 staffing**, now confirmed verbally along
> with a 24-person link. The question is kept below as it was asked.

Seeded from today's duties, 24 lines average **29h 53m** a week against a 35h contract. The live
20-line roster gives exactly **35h 00m** — that is the check on the measure, not a coincidence.
The gap is **123 hours of duty a week of rotation** at four cover weeks (88h at five).

**The generator refuses to build a design that misses the contract in either direction**, so this is
not a warning that can be scrolled past; it is a blocked action with the gap named. Note the shape
of what it asks for: the target is an **equality**, so overshooting is refused too — the extra
service has to land on a table totalling exactly `working × 35h`.

*What turns on it:* either the December 2026 service supplies the work — in which case the targets
should be seeded from the new timetable rather than today's roster — or a widened link does not fill
a contracted week and the proposal is about headcount, not patterns. **This is the argument the tool
was built to make and it has made it:** a service increase cannot be absorbed by making existing
lines denser.

---

**4 · The business staffing requirement.** *What is the station actually required to staff?*

**Confirmed verbally (owner, 29 Sep 2026)**, together with the 24-person link and the Sunday cover.
The owner relayed the December 2026 staffing levels on 27–28 Sep 2026, and every sheet is judged
against them as 11 rules (four at the open, three at the close, five at 22:00, 14 on a Saturday and
10 on a Sunday, the ticket office in fixed pairs, and the rest — `currentRules` in
`docs/proposals/tooling/report-data.mjs`). Each sheet and the rules sheet say *confirmed verbally*.

*What turned on it:* whether every proposal was being assessed against the standard it will be
judged on. It is.

---

**And one that is a decision rather than a question:** the hard company limits (13 consecutive days)
are cited to a policy nobody has identified — evidence class C, on the ROADMAP's scale. Every
surface that states the limit carries provisional wording until a controlled source is named, and
`POLICY_SOURCE_CONFIRMED` is the single switch that clears all of them at once. Getting the title,
clause, staff group and effective date is a task, not a discussion.

---

## What this plan does not know

Recorded so the gaps are visible rather than implied:

- **The CURRENT timetable.** Every service figure in this document is December 2026; today's is not
  measured anywhere. Recorded as a gap, **not** a blocker on package 4 — that framing was corrected
  by the owner: the tool already holds today's STAFFING, and the uplift is a figure the business
  states rather than one derived from two timetables.
- **Whether "coverage vs service" is the business requirement at all.** Answered: the December
  2026 staffing levels were relayed on 27–28 Sep 2026, confirmed verbally on 29 Sep, and are the rules
  every sheet is judged against. Before that it was an inference from the data, not something
  Nathan stated. He said business requirements and fatigue guidelines;
  the fatigue half is documented on p3, the business half is not written down anywhere here.
  Partly softened by the posts steer above — the requirement is now known to be posts + relief +
  a train-driven remainder — but nobody has confirmed that is what the proposals will be judged on.
- ~~**What CEAs actually do at Marylebone hour by hour**~~ — **PARTLY ANSWERED (owner, Aug 2026), and
  it changes the demand model.** See "What actually drives CEA headcount" above. The remaining unknowns are
  the numbers, not the structure.
- **Whether other grades cover the window's edges.** The 05:55 first departure and the post-midnight
  last trains sit outside the CEA link; something covers them, and knowing what would settle whether
  the Sunday finish is really a gap.
- **The timing — now partly addressed.** No package here was sized against the "See Nathan" days,
  because their date is not known. That is still true of the MEETING date, but the readiness
  dashboard at the top of this file now carries a backwards plan from the timetable change itself
  (T−12 … T−1), so the absence of one fixed date no longer means the absence of any dates. **Pin T,
  then set the real intervals with Nathan.** If the room is booked before everything lands, the
  useful minimum is unchanged: the baseline table above printed alongside the current link.
